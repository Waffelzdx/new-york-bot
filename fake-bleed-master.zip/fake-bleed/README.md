leaked source code to a fake bleed bot clone made by some 13 year old loser named amir (aka four)

good luck getting this taken down nerd

leaked by https://twitter.com/S8X
